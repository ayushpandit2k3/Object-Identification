import cv2
import numpy as np
import time
import os
weights_path = r"yolov4-tiny.weights"
cfg_path = r"yolov4-tiny.cfg"
names_path = r"coco.names"
net = cv2.dnn.readNet(weights_path, cfg_path)
use_cuda = False
try:
    if cv2.cuda.getCudaEnabledDeviceCount() > 0:
        net.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
        net.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA)
        use_cuda = True
except:
    pass
if use_cuda:
    print("[INFO] GPU (CUDA) enabled.")
else:
    net.setPreferableBackend(cv2.dnn.DNN_BACKEND_DEFAULT)
    net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
    print("[INFO] Running on CPU.")
with open(names_path, "r") as f:
    classes = [line.strip() for line in f.readlines()]
layer_names = net.getLayerNames()
output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers().flatten()]
url = 'http://URL from droidcam app/video'
cap = cv2.VideoCapture(url)
frame_skip = 3
frame_id = 0
colors = np.random.uniform(0, 255, size=(len(classes), 3))
print("[INFO] Object detection started. Press 'q' to exit.")
while True:
    ret, frame = cap.read()
    if not ret:
        print("[WARNING] Failed to grab frame.")
        break
    frame_id += 1
    if frame_id % frame_skip != 0:
        continue
    start = time.time()
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(cv2.resize(frame, (416, 416)),
                                 1 / 255.0, (416, 416),
                                 swapRB=True, crop=False)
    net.setInput(blob)
    outputs = net.forward(output_layers)
    boxes, confidences, class_ids = [], [], []
    for output in outputs:
        for detection in output:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.6:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)
    indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.6, 0.4)
    if isinstance(indexes, (list, np.ndarray)) and len(indexes) > 0:
        for i in np.array(indexes).flatten():
            x, y, w, h = boxes[i]
            label = f"{classes[class_ids[i]]}: {confidences[i]:.2f}"
            color = colors[class_ids[i]]
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 3)
            (text_w, text_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(frame, (x, y - 20), (x + text_w, y), color, -1)
            cv2.putText(frame, label, (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    end = time.time()
    fps = 1 / (end - start)
    cv2.putText(frame, f"FPS: {fps:.2f}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    display_frame = cv2.resize(frame, (640, 480))
    cv2.imshow("YOLOv4-Tiny Detection", display_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print("[INFO] Exiting...")
        break
cap.release()
cv2.destroyAllWindows()